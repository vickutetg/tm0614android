package com.hoangphan.tutor0901_threading;

public class CountThread extends Thread {
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	

}
