package com.hoangphan.game2048improve;

public class Config {

	public static final int LINES = 4;
	public static int CARD_WIDTH = 0;
}
