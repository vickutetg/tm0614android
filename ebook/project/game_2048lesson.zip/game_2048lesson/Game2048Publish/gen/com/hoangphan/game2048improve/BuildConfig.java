/** Automatically generated file. DO NOT MODIFY */
package com.hoangphan.game2048improve;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}