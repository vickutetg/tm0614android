/** Automatically generated file. DO NOT MODIFY */
package com.example.colorist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}