/** Automatically generated file. DO NOT MODIFY */
package com.namnguyen.namnh_student_management;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}