package com.hoangphan.tutor0301_wjpass;

public class Constant {

  public static final int REQUEST_FROM1_TO2 = 100;
  public static final int REQUEST_FROM2_TO3 = 200;

}
