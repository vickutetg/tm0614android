/** Automatically generated file. DO NOT MODIFY */
package com.hoangphan.tutor0301_wjpass;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}