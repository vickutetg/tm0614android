/** Automatically generated file. DO NOT MODIFY */
package com.hoanghiep.giaiphuongtrinh;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}