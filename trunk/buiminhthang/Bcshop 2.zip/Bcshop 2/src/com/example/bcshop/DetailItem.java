package com.example.bcshop;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DetailItem extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detail_item);
		Intent i = getIntent();
		String title = i.getStringExtra("TITLE");
		TextView title_detail = (TextView) findViewById(R.id.textView1);
		title_detail.setText(title);
//		Toast.makeText(DetailItem.this, "You Clicked at " + title[+position],
//				Toast.LENGTH_SHORT).show();
	}

}
