/** Automatically generated file. DO NOT MODIFY */
package com.hoangphan.tutor0102_helloandr;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}