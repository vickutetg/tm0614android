SwipeListView
=====================

This Android library provides ListViews in which items can be swiped and deleted by swipe.

To know how to use it, see the sample project. 
