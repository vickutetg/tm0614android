This library enables to add a side navigation drawer easily for an Android application.

SimpleNavDrawer Library
=========================

This library simply enables to add a side navigation drawer for an Android application. 


History
========
Ver0.0.1 Oct 24, 2012


Stuff
========
Masahiko Adachi(http://adamrocker.com)