/** Automatically generated file. DO NOT MODIFY */
package com.navdrawer.demo.simple;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}