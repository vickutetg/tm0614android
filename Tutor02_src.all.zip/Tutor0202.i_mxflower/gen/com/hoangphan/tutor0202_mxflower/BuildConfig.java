/** Automatically generated file. DO NOT MODIFY */
package com.hoangphan.tutor0202_mxflower;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}